export const i18n = {
  defaultLocale: 'nl',
  locales: ['nl', 'fr']
};
